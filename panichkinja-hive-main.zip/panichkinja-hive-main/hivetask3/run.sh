#! /bin/bash

hive -f agent_stats.sql

