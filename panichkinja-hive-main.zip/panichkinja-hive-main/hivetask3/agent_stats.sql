ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-contrib.jar;
USE panichkinja;

SET mapred.job.name=punisher_agent_stat_evaluation;

SELECT l.userAgent as userAgent,
       SUM(CASE WHEN u.sex == "male" THEN 1 ELSE 0 END) as male,
       SUM(CASE WHEN u.sex == "female" THEN 1 ELSE 0 END) as female
FROM Logs AS l
         INNER JOIN Users AS u ON l.ip == u.ip
GROUP BY l.userAgent;

