ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-contrib.jar;
USE panichkinja;

SELECT TRANSFORM ( ip, requestDate, requestContent, pageSize, responseCode, userAgent) USING 'sed "s/http/ftp/"'
FROM Logs LIMIT 10;

