#! /bin/bash

hive -f replace.sql

