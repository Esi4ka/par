package com.hobod;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;

import java.util.ArrayList;
import java.util.List;
import java.util.BitSet;
import java.lang.Math;


public class GetIPSUDTF extends GenericUDTF {
    private Object[] forwardObjArray = new Object[2];

    private StringObjectInspector inputAddress;
    private StringObjectInspector inputMask;

    public long getIpValue(byte[] octets) {
        long value = 0;
        for (int i = 3; i >= 0; i--) {
            long octet = octets[i] & 0xFF;
            value = 256 * value + octet;
        }

        return value;
    }

    public String getIpString(byte[] octets) {
        return String.format("%d.%d.%d.%d",
                             ((int) octets[3]) & 0xFF,
                             ((int) octets[2]) & 0xFF,
                             ((int) octets[1]) & 0xFF,
                             ((int) octets[0]) & 0xFF);
    }

    public BitSet ipBitsFromValue(long value) {
        return BitSet.valueOf(new byte[] {
            (byte)value,
            (byte)(value >>> 8),
            (byte)(value >>> 16),
            (byte)(value >>> 24)}
        );
    }

    @Override
    public StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException {
        // Parsing an input data
        if(args.length != 2){  // Checking the quantity of arguments
            throw new UDFArgumentException(getClass().getSimpleName() + " takes only 2 argument!");
        }
        inputAddress = (StringObjectInspector) args[0];
        inputMask = (StringObjectInspector) args[1];

        // Describing the structure for output
        final List<String> fieldNames = new ArrayList<String>(){
            {
                add("ip");
                add("ip_value");
            }
        };

        final List<ObjectInspector> fieldInspectors = new ArrayList<ObjectInspector>(){
            {
                add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
                add(PrimitiveObjectInspectorFactory.javaLongObjectInspector);
            }
        }; // Inspector to check that each field is String

        return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldInspectors);
    }

    @Override
    public void process(Object[] objects) throws HiveException {
        String currentAddr = inputAddress.getPrimitiveJavaObject(objects[0]);
        String currentMask = inputMask.getPrimitiveJavaObject(objects[1]);

        String[] addrOctets = currentAddr.split("\\.");
        String[] maskOctets = currentMask.split("\\.");
        BitSet addrBits = new BitSet(32);
        BitSet maskBits = new BitSet(32);

        byte[] addrBytes = {0, 0, 0, 0};
        byte[] maskBytes = {0, 0, 0, 0};
        for (int i = 0; i < 4; i++) {
            addrBytes[3 - i] = (byte) Integer.parseInt(addrOctets[i]);
            maskBytes[3 - i]= (byte) Integer.parseInt(maskOctets[i]);
        }
        addrBits.or(BitSet.valueOf(addrBytes));
        maskBits.or(BitSet.valueOf(maskBytes));

        BitSet networkAddr = (BitSet) maskBits.clone();
        networkAddr.and(addrBits);

        long networkAddrValue = getIpValue(networkAddr.toByteArray());
        long ipNum = (long) Math.pow(2, 32 - maskBits.cardinality());
        for (long ip = 0; ip < ipNum; ip++) {
            BitSet ipBits = ipBitsFromValue(ip);
            ipBits.or(networkAddr);
            forwardObjArray[0] = getIpString(ipBits.toByteArray());
            forwardObjArray[1] = networkAddrValue + ip;

            forward(forwardObjArray);
        }
    }

    @Override
    public void close() throws HiveException {
    }
}
