#! /bin/bash

hive -f ips.sql

