ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-contrib.jar;
ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-exec.jar;
ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-serde.jar;
ADD JAR GetIPS/target/GetIPS-1.0-SNAPSHOT.jar;

USE panichkinja;

CREATE TEMPORARY FUNCTION getips AS 'com.hobod.GetIPSUDTF';

SELECT getips(ip, mask) from Subnets LIMIT 100;