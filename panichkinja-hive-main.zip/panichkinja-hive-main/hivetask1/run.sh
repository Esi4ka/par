#! /bin/bash

hive -f db_init.sql
