ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-contrib.jar;
ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-serde.jar;
USE panichkinja;

SET mapred.job.name=punisher;

-- Not partitioned logs
DROP TABLE IF EXISTS FullLogs;

CREATE EXTERNAL TABLE FullLogs (
	ip STRING,
	requestDate INT,
	requestContent STRING,
	pageSize SMALLINT,
	responseCode SMALLINT,
	userAgent STRING
) ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.RegexSerDe'
WITH SERDEPROPERTIES (
	"input.regex" = '^(\\S+)\\t{3}(\\d{8})\\d+\\t(\\S*)\\t(\\d+)\\t(\\d+)\\t(\\S+)[^\\S].*$'
)
STORED AS TEXTFILE
LOCATION '/data/user_logs/user_logs_M';

-- Users
DROP TABLE IF EXISTS Users;

CREATE EXTERNAL TABLE Users (
    ip STRING,
    userAgent STRING,
    sex STRING,
    age TINYINT
) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/data/user_logs/user_data_M';

-- IPRegions
DROP TABLE IF EXISTS IPRegions;

CREATE EXTERNAL TABLE IPRegions (
    ip STRING,
    region STRING
) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/data/user_logs/ip_data_M';

-- Subnets
DROP TABLE IF EXISTS Subnets;

CREATE EXTERNAL TABLE Subnets (
    ip STRING,
    mask STRING
) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/data/subnets/variant2';

-- partition
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.max.dynamic.partitions.pernode = 300;

DROP TABLE IF EXISTS Logs;

CREATE EXTERNAL TABLE Logs (
    ip STRING,
    requestContent STRING,
    pageSize SMALLINT,
    responseCode SMALLINT,
    userAgent STRING
)
PARTITIONED BY (requestDate INT)
STORED AS TEXTFILE;

INSERT OVERWRITE TABLE Logs PARTITION (requestDate)
SELECT ip, requestContent, pageSize, responseCode, userAgent, requestDate FROM FullLogs;

SELECT * FROM Logs LIMIT 10;
SELECT * FROM Users LIMIT 10;
SELECT * FROM IPRegions LIMIT 10;
SELECT * FROM Subnets LIMIT 10;

