package com.hobod;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(
        name = "Div1024",
        value = "Returns number divided by 1024",
        extended = "Example:\n" +
                "SELECT Div1024(field) from a;"
)
public class Div1024UDF extends UDF {

    public int evaluate(int num){
        return num / 1024;
    }
}
