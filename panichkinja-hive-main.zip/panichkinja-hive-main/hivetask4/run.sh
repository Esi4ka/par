#! /bin/bash

hive -f top10sz.sql

