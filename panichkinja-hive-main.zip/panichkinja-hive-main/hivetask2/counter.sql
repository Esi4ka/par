ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-contrib.jar;
USE panichkinja;

SET mapred.job.name=punisher_counter;

SELECT requestDate, COUNT(DISTINCT responseCode) as countRC FROM Logs GROUP BY requestDate ORDER BY countRC DESC;

