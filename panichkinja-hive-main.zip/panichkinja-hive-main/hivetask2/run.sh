#! /bin/bash

hive -f counter.sql

